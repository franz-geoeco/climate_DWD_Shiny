"""Exposes DWD Climate Explorer's data-fetching as QGIS Processing
algorithms, so they're usable from Model Builder, the Processing history,
batch mode, and `qgis_process` -- not just the dock widget."""
import os
from datetime import datetime

import pandas as pd
from qgis.core import (
    Qgis, QgsProcessingAlgorithm, QgsProcessingProvider,
    QgsProcessingParameterNumber, QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterFolderDestination, QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFeatureSink, QgsProcessingException,
    QgsFields, QgsField, QgsFeature, QgsFeatureSink,
    QgsCoordinateReferenceSystem, QgsRasterLayer,
    QgsProcessingLayerPostProcessorInterface,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QIcon

from . import dwd_client as c
from . import station_layer as sl
from . import raster_layer as rl
from . import pheno_layer as pl
from . import timeline as tl

ICON_PATH = os.path.join(os.path.dirname(__file__), "icons", "dwd_icon.svg")

RASTER_VARIABLES = list(c.RASTER_CATALOGUE.keys())
RASTER_VARIABLE_LABELS = [c.RASTER_CATALOGUE[k]["label"] for k in RASTER_VARIABLES]
PERIOD_CODES = list(c.PERIOD_LABELS.keys())
PERIOD_LABELS_LIST = [c.PERIOD_LABELS[k] for k in PERIOD_CODES]
YEAR_CODES = list(c.YEAR_RANGE_LABELS.keys())
YEAR_LABELS_LIST = [c.YEAR_RANGE_LABELS[k] for k in YEAR_CODES]

PHENO_REPORTER_KEYS = list(c.PHENO_REPORTER_TYPES.keys())
PHENO_REPORTER_LABELS = [c.PHENO_REPORTER_TYPES[k]["label"] for k in PHENO_REPORTER_KEYS]
PHENO_COMBO_KEYS = list(c.PHENO_CATEGORIES.keys())
RADOLAN_KEYS = list(c.RADOLAN_PRODUCTS.keys())
RADOLAN_LABELS = [c.RADOLAN_PRODUCTS[k]["label"] for k in RADOLAN_KEYS]
PHENO_COMBO_LABELS = [
    f"{'Annual' if rep == 'annual' else 'Immediate'} reporters – {c.PHENO_CATEGORIES[(rep, cat)]['label']}"
    for rep, cat in PHENO_COMBO_KEYS
]


class _StyleRasterPostProcessor(QgsProcessingLayerPostProcessorInterface):
    """Applies the same colour ramp the dock widget uses, once Processing
    has loaded the output layer. Must be kept alive (self._post_processor)
    until postProcessLayer actually runs -- the interface isn't a QObject,
    so nothing else holds a reference to it."""

    def __init__(self, variable):
        super().__init__()
        self.variable = variable

    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsRasterLayer):
            return
        layer.setCrs(QgsCoordinateReferenceSystem(rl.GRID_CRS))
        rl._style_layer(layer, c.RASTER_CATALOGUE[self.variable]["palette"])


class _StyleDeltaPostProcessor(QgsProcessingLayerPostProcessorInterface):
    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsRasterLayer):
            return
        layer.setCrs(QgsCoordinateReferenceSystem(rl.GRID_CRS))
        rl._style_delta_layer(layer)


class _StyleRadolanPostProcessor(QgsProcessingLayerPostProcessorInterface):
    def __init__(self, vmax):
        super().__init__()
        self.vmax = vmax

    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsRasterLayer):
            return
        layer.setCrs(rl.radolan_crs())
        rl._style_layer(layer, c.RADOLAN_PALETTE, vmin=0.0, vmax=self.vmax)


class _PhenoObsPostProcessor(QgsProcessingLayerPostProcessorInterface):
    def postProcessLayer(self, layer, context, feedback):
        try:
            pl.apply_doy_renderer(layer)
            tl.set_vector_time_fields(layer, "obs_date", "visible_to")
        except Exception:
            pass


def _progress_feedback(feedback):
    def progress(i, n, msg):
        feedback.setProgress(int(100 * i / max(n, 1)))
        feedback.pushInfo(msg)
        if feedback.isCanceled():
            raise QgsProcessingException("Cancelled by user")
    return progress


class DWDProcessingProvider(QgsProcessingProvider):
    def id(self):
        return "dwdclimateexplorer"

    def name(self):
        return "DWD Climate Explorer"

    def icon(self):
        return QIcon(ICON_PATH)

    def loadAlgorithms(self):
        self.addAlgorithm(FetchStationListAlgorithm())
        self.addAlgorithm(FetchStationDataAlgorithm())
        self.addAlgorithm(FetchRasterGridAlgorithm())
        self.addAlgorithm(DeltaRasterAlgorithm())
        self.addAlgorithm(FetchPhenologyStationListAlgorithm())
        self.addAlgorithm(FetchPhenologyDataAlgorithm())
        self.addAlgorithm(FetchPhenologyObservationsAlgorithm())
        self.addAlgorithm(FetchRadolanAlgorithm())


class _DWDAlgorithmBase(QgsProcessingAlgorithm):
    def group(self):
        return "DWD Climate Explorer"

    def groupId(self):
        return "dwdclimateexplorer"


class FetchStationListAlgorithm(_DWDAlgorithmBase):
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_station_list"

    def displayName(self):
        return "Fetch DWD station list"

    def shortHelpString(self):
        return ("Downloads the current DWD station description files and builds a point "
                "layer of every station, colour-coded by data-availability tier "
                "(full / climate-only / basic / none).")

    def createInstance(self):
        return FetchStationListAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "DWD stations"))

    def processAlgorithm(self, parameters, context, feedback):
        feedback.pushInfo("Fetching station description files from opendata.dwd.de...")
        index = c.build_station_index(progress_cb=_progress_feedback(feedback))
        layer = sl.build_station_layer(index.stations)

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, layer.fields(), Qgis.WkbType.Point, layer.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        for feat in layer.getFeatures():
            sink.addFeature(feat, QgsFeatureSink.FastInsert)

        try:
            details = context.layerToLoadOnCompletionDetails(dest_id)
            processor = _TierStylePostProcessor()
            details.setPostProcessor(processor)
            self._post_processor = processor
        except Exception:
            pass

        feedback.pushInfo(f"{len(index.stations)} stations written.")
        return {self.OUTPUT: dest_id}


class _TierStylePostProcessor(QgsProcessingLayerPostProcessorInterface):
    def postProcessLayer(self, layer, context, feedback):
        try:
            sl._apply_tier_renderer(layer)
        except Exception:
            pass


class FetchStationDataAlgorithm(_DWDAlgorithmBase):
    STATION_ID = "STATION_ID"
    OUTPUT_FOLDER = "OUTPUT_FOLDER"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_station_data"

    def displayName(self):
        return "Fetch DWD station climate data"

    def shortHelpString(self):
        return ("Downloads daily climate, monthly climate, hourly wind and annual "
                "climate-index data for one DWD station (by station ID). Monthly/wind/"
                "indices are written as CSV to the output folder; the daily climate "
                "series is also loaded as a table.")

    def createInstance(self):
        return FetchStationDataAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterNumber(
            self.STATION_ID, "DWD station ID", Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=3987, minValue=1))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_FOLDER, "Folder for monthly / wind / indices CSVs"))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Daily climate table"))

    def processAlgorithm(self, parameters, context, feedback):
        station_id = self.parameterAsInt(parameters, self.STATION_ID, context)
        out_folder = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        os.makedirs(out_folder, exist_ok=True)

        feedback.pushInfo("Looking up station list...")
        index = c.build_station_index(progress_cb=_progress_feedback(feedback))
        rows = index.stations[index.stations["Stations_id"] == station_id]
        if len(rows) == 0:
            raise QgsProcessingException(f"Station ID {station_id} not found.")
        station_row = rows.iloc[0]

        bundle = c.fetch_station_bundle(index, station_row, progress_cb=_progress_feedback(feedback))

        for key, fname in (("data_chart", "monthly_climate.csv"),
                            ("data_wind", "hourly_wind.csv"),
                            ("data_indices", "annual_indices.csv")):
            df = bundle.get(key)
            if df is not None:
                df.to_csv(os.path.join(out_folder, fname), index=False, encoding="utf-8")
                feedback.pushInfo(f"Wrote {fname} ({len(df)} rows)")
            else:
                feedback.pushInfo(f"{fname}: not available for this station")

        daily = bundle.get("data")
        cols = [col for col in daily.columns if col != "_date"] if daily is not None else []
        fields = QgsFields()
        for col in cols:
            fields.append(QgsField(col, QVariant.String))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields, Qgis.WkbType.NoGeometry,
            QgsCoordinateReferenceSystem())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        if daily is not None:
            for _, row in daily.iterrows():
                feat = QgsFeature(fields)
                feat.setAttributes([None if pd.isna(row[col]) else str(row[col]) for col in cols])
                sink.addFeature(feat, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id, self.OUTPUT_FOLDER: out_folder}


class FetchRasterGridAlgorithm(_DWDAlgorithmBase):
    VARIABLE = "VARIABLE"
    PERIOD = "PERIOD"
    YEAR = "YEAR"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_raster_grid"

    def displayName(self):
        return "Fetch DWD climate grid"

    def shortHelpString(self):
        return ("Downloads a Germany-wide 1km DWD multi-annual climate grid (temperature, "
                "precipitation, sunshine duration, or a day-count index) for the chosen "
                "month/season/year and reference period, styled with the same colour ramp "
                "as the dock widget's Raster Grids tab.")

    def createInstance(self):
        return FetchRasterGridAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.VARIABLE, "Variable", options=RASTER_VARIABLE_LABELS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.PERIOD, "Period", options=PERIOD_LABELS_LIST,
            defaultValue=PERIOD_CODES.index("17")))
        self.addParameter(QgsProcessingParameterEnum(
            self.YEAR, "Reference period", options=YEAR_LABELS_LIST,
            defaultValue=len(YEAR_CODES) - 1))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Output grid"))

    def processAlgorithm(self, parameters, context, feedback):
        variable = RASTER_VARIABLES[self.parameterAsEnum(parameters, self.VARIABLE, context)]
        period = PERIOD_CODES[self.parameterAsEnum(parameters, self.PERIOD, context)]
        year_code = YEAR_CODES[self.parameterAsEnum(parameters, self.YEAR, context)]
        meta = c.RASTER_CATALOGUE[variable]
        if meta["periods"] == "annual_only" and period != "17":
            feedback.pushWarning(f"{meta['label']} only has an annual grid; ignoring the chosen period.")
            period = "17"

        dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        feedback.pushInfo("Downloading grid from opendata.dwd.de...")
        _asc_path, url = c.fetch_raster_grid(variable, period, year_code, dest)
        feedback.pushInfo(f"Downloaded {url}")
        rl.write_prj_sidecar(dest)

        try:
            details = context.layerToLoadOnCompletionDetails(dest)
            processor = _StyleRasterPostProcessor(variable)
            details.setPostProcessor(processor)
            self._post_processor = processor
        except Exception:
            pass

        return {self.OUTPUT: dest}


class DeltaRasterAlgorithm(_DWDAlgorithmBase):
    VARIABLE = "VARIABLE"
    PERIOD = "PERIOD"
    YEAR_A = "YEAR_A"
    YEAR_B = "YEAR_B"
    OUTPUT = "OUTPUT"

    def name(self):
        return "delta_raster_grid"

    def displayName(self):
        return "DWD climate change map (delta)"

    def shortHelpString(self):
        return ("Downloads the same DWD climate grid for two reference periods and maps "
                "period B minus period A -- e.g. 1991-2020 minus 1961-1990 mean temperature "
                "shows where and how much Germany has warmed. Styled with a diverging ramp "
                "centred on zero.")

    def createInstance(self):
        return DeltaRasterAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.VARIABLE, "Variable", options=RASTER_VARIABLE_LABELS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.PERIOD, "Period", options=PERIOD_LABELS_LIST,
            defaultValue=PERIOD_CODES.index("17")))
        self.addParameter(QgsProcessingParameterEnum(
            self.YEAR_A, "Reference period A (subtracted)", options=YEAR_LABELS_LIST,
            defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.YEAR_B, "Reference period B (minus A)", options=YEAR_LABELS_LIST,
            defaultValue=len(YEAR_CODES) - 1))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "Change map (B - A)"))

    def processAlgorithm(self, parameters, context, feedback):
        variable = RASTER_VARIABLES[self.parameterAsEnum(parameters, self.VARIABLE, context)]
        period = PERIOD_CODES[self.parameterAsEnum(parameters, self.PERIOD, context)]
        year_a = YEAR_CODES[self.parameterAsEnum(parameters, self.YEAR_A, context)]
        year_b = YEAR_CODES[self.parameterAsEnum(parameters, self.YEAR_B, context)]
        if year_a == year_b:
            raise QgsProcessingException("Period A and period B must be different.")
        meta = c.RASTER_CATALOGUE[variable]
        if meta["periods"] == "annual_only" and period != "17":
            period = "17"

        import tempfile
        tmp_a = tempfile.NamedTemporaryFile(suffix=f"_{year_a}.asc", delete=False).name
        tmp_b = tempfile.NamedTemporaryFile(suffix=f"_{year_b}.asc", delete=False).name

        feedback.pushInfo(f"Downloading period A ({c.YEAR_RANGE_LABELS[year_a]})...")
        c.fetch_raster_grid(variable, period, year_a, tmp_a)
        feedback.pushInfo(f"Downloading period B ({c.YEAR_RANGE_LABELS[year_b]})...")
        c.fetch_raster_grid(variable, period, year_b, tmp_b)

        dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        feedback.pushInfo("Computing delta with the raster calculator...")
        rl.compute_delta_grid(tmp_a, tmp_b, dest)

        for tmp in (tmp_a, tmp_b):
            try:
                os.remove(tmp)
                os.remove(tmp + ".prj")
            except OSError:
                pass

        try:
            details = context.layerToLoadOnCompletionDetails(dest)
            processor = _StyleDeltaPostProcessor()
            details.setPostProcessor(processor)
            self._post_processor = processor
        except Exception:
            pass

        return {self.OUTPUT: dest}


def _match_species(species_index, species_input):
    """Species token for a user-typed name: token or label, case-insensitive,
    spaces and underscores interchangeable."""
    needle = species_input.lower().replace(" ", "_")
    for candidate_token, entry in species_index.species.items():
        if candidate_token.lower() == needle or entry["label"].lower() == species_input.lower():
            return candidate_token, entry["label"]
    available = ", ".join(sorted(e["label"] for e in species_index.species.values()))
    raise QgsProcessingException(
        f"Species '{species_input}' not found for this category. Available: {available}")


class FetchPhenologyStationListAlgorithm(_DWDAlgorithmBase):
    REPORTER = "REPORTER"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_phenology_station_list"

    def displayName(self):
        return "Fetch DWD phenology station list"

    def shortHelpString(self):
        return ("Downloads the DWD phenology station list for the chosen reporter type "
                "(annual/Jahresmelder or immediate/Sofortmelder) and builds a point layer. "
                "This is a separate station network from the climate stations -- different "
                "IDs, different coverage.")

    def createInstance(self):
        return FetchPhenologyStationListAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.REPORTER, "Reporter type", options=PHENO_REPORTER_LABELS, defaultValue=0))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "DWD phenology stations"))

    def processAlgorithm(self, parameters, context, feedback):
        idx = self.parameterAsEnum(parameters, self.REPORTER, context)
        reporter = PHENO_REPORTER_KEYS[idx]
        feedback.pushInfo("Fetching phenology station list from opendata.dwd.de...")
        stations = c.fetch_phenology_stations(reporter)
        layer = pl.build_pheno_station_layer(stations, PHENO_REPORTER_LABELS[idx])

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, layer.fields(), Qgis.WkbType.Point, layer.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        for feat in layer.getFeatures():
            sink.addFeature(feat, QgsFeatureSink.FastInsert)

        feedback.pushInfo(f"{len(stations)} phenology stations written.")
        return {self.OUTPUT: dest_id}


class FetchPhenologyDataAlgorithm(_DWDAlgorithmBase):
    CATEGORY = "CATEGORY"
    SPECIES = "SPECIES"
    STATION_ID = "STATION_ID"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_phenology_data"

    def displayName(self):
        return "Fetch DWD phenology data"

    def shortHelpString(self):
        return ("Downloads plant development-stage observations (sowing, flowering, ripening, "
                "leaf colouring, ...) for one species at one phenology station -- a separate "
                "station network from the climate stations used by the other algorithms; run "
                "'Fetch DWD phenology station list' first to find a station ID. SPECIES must "
                "match a species name from the dock widget's Phenology tab for the chosen "
                "reporter type / category (e.g. 'Schneegloeckchen', spaces or underscores both "
                "work, case-insensitive).")

    def createInstance(self):
        return FetchPhenologyDataAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.CATEGORY, "Reporter type / category", options=PHENO_COMBO_LABELS, defaultValue=0))
        self.addParameter(QgsProcessingParameterString(
            self.SPECIES, "Species (e.g. 'Schneegloeckchen')"))
        self.addParameter(QgsProcessingParameterNumber(
            self.STATION_ID, "Phenology station ID", Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=164, minValue=1))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "Phenology records"))

    def processAlgorithm(self, parameters, context, feedback):
        reporter, category = PHENO_COMBO_KEYS[self.parameterAsEnum(parameters, self.CATEGORY, context)]
        species_input = self.parameterAsString(parameters, self.SPECIES, context).strip()
        station_id = self.parameterAsInt(parameters, self.STATION_ID, context)

        feedback.pushInfo(f"Looking up species list for {reporter}/{category}...")
        species_index = c.list_phenology_species(reporter, category)
        token, matched_label = _match_species(species_index, species_input)

        feedback.pushInfo(f"Fetching '{matched_label}' data for station {station_id}...")
        df = c.fetch_phenology_species_data(
            reporter, category, token, station_id, species_index=species_index)
        if df is None:
            df = pd.DataFrame()
        if len(df) == 0:
            feedback.pushWarning("No phenology records found for this station/species.")

        cols = [col for col in df.columns if col != "_date"]
        fields = QgsFields()
        for col in cols:
            fields.append(QgsField(col, QVariant.String))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields, Qgis.WkbType.NoGeometry,
            QgsCoordinateReferenceSystem())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        for _, row in df.iterrows():
            feat = QgsFeature(fields)
            feat.setAttributes([None if pd.isna(row[col]) else str(row[col]) for col in cols])
            sink.addFeature(feat, QgsFeatureSink.FastInsert)

        feedback.pushInfo(f"{len(df)} phenology records written.")
        return {self.OUTPUT: dest_id}


class FetchPhenologyObservationsAlgorithm(_DWDAlgorithmBase):
    CATEGORY = "CATEGORY"
    SPECIES = "SPECIES"
    PHASE_ID = "PHASE_ID"
    YEAR_FROM = "YEAR_FROM"
    YEAR_TO = "YEAR_TO"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_phenology_observations"

    def displayName(self):
        return "Fetch DWD phenology observations (all stations)"

    def shortHelpString(self):
        return ("Builds a point layer of every station's entry date of one phenological "
                "phase for one species over a year range, coloured by day of year and "
                "time-aware (in the Temporal Controller each point is visible from its entry "
                "date to the end of that year). PHASE_ID 0 keeps every phase; phase IDs are "
                "listed in DWD's PH_Beschreibung_Phase.txt and in the dock widget's Phenology "
                "tab. SPECIES as for 'Fetch DWD phenology data'.")

    def createInstance(self):
        return FetchPhenologyObservationsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.CATEGORY, "Reporter type / category", options=PHENO_COMBO_LABELS, defaultValue=0))
        self.addParameter(QgsProcessingParameterString(
            self.SPECIES, "Species (e.g. 'Schneegloeckchen')"))
        self.addParameter(QgsProcessingParameterNumber(
            self.PHASE_ID, "Phase ID (0 = all phases)", Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=0, minValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.YEAR_FROM, "First year", Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=1991, minValue=1900))
        self.addParameter(QgsProcessingParameterNumber(
            self.YEAR_TO, "Last year", Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=datetime.now().year, minValue=1900))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "Phenology observations"))

    def processAlgorithm(self, parameters, context, feedback):
        reporter, category = PHENO_COMBO_KEYS[self.parameterAsEnum(parameters, self.CATEGORY, context)]
        species_input = self.parameterAsString(parameters, self.SPECIES, context).strip()
        phase_id = self.parameterAsInt(parameters, self.PHASE_ID, context) or None
        y0 = self.parameterAsInt(parameters, self.YEAR_FROM, context)
        y1 = self.parameterAsInt(parameters, self.YEAR_TO, context)

        feedback.pushInfo(f"Looking up species list for {reporter}/{category}...")
        species_index = c.list_phenology_species(reporter, category)
        token, matched_label = _match_species(species_index, species_input)
        feedback.pushInfo("Fetching phenology station list...")
        stations = c.fetch_phenology_stations(reporter)
        feedback.pushInfo(f"Fetching all '{matched_label}' observations...")
        df = c.fetch_phenology_observations(reporter, category, token, stations,
                                            phase_id=phase_id, year_range=(y0, y1),
                                            species_index=species_index)
        if df is None or len(df) == 0:
            raise QgsProcessingException("No observations match this species / phase / year range.")
        layer = pl.build_pheno_obs_layer(df, matched_label)

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, layer.fields(), Qgis.WkbType.Point, layer.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        for feat in layer.getFeatures():
            sink.addFeature(feat, QgsFeatureSink.FastInsert)

        try:
            details = context.layerToLoadOnCompletionDetails(dest_id)
            processor = _PhenoObsPostProcessor()
            details.setPostProcessor(processor)
            self._post_processor = processor
        except Exception:
            pass

        feedback.pushInfo(f"{len(df)} observations at {df['Stations_id'].nunique()} stations written.")
        return {self.OUTPUT: dest_id}


class FetchRadolanAlgorithm(_DWDAlgorithmBase):
    PRODUCT = "PRODUCT"
    DATE = "DATE"
    HOUR = "HOUR"
    OUTPUT = "OUTPUT"

    def name(self):
        return "fetch_radolan"

    def displayName(self):
        return "Fetch RADOLAN precipitation grid"

    def shortHelpString(self):
        return ("Downloads one RADOLAN radar precipitation grid (1km, all of Germany, 2005 "
                "onwards) as a GeoTIFF in mm: RW = 1-hour sum ending at HOUR:50 UTC on DATE, "
                "SF = 24-hour sum ending 23:50 UTC on DATE (HOUR ignored). Dates older than "
                "DWD's 'recent' window are read from monthly archives (~40 MB, cached in the "
                "temp folder).")

    def createInstance(self):
        return FetchRadolanAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.PRODUCT, "Product", options=RADOLAN_LABELS, defaultValue=RADOLAN_KEYS.index("SF")))
        self.addParameter(QgsProcessingParameterString(self.DATE, "Date (YYYY-MM-DD, UTC)"))
        self.addParameter(QgsProcessingParameterNumber(
            self.HOUR, "Hour the RW interval ends (0-23, at HH:50 UTC)",
            Qgis.ProcessingNumberParameterType.Integer, defaultValue=12, minValue=0, maxValue=23))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, "RADOLAN grid"))

    def processAlgorithm(self, parameters, context, feedback):
        product = RADOLAN_KEYS[self.parameterAsEnum(parameters, self.PRODUCT, context)]
        date_str = self.parameterAsString(parameters, self.DATE, context).strip()
        try:
            day = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            raise QgsProcessingException(f"Date '{date_str}' is not in YYYY-MM-DD format.")
        hour = self.parameterAsInt(parameters, self.HOUR, context) if product == "RW" else None

        feedback.pushInfo(f"Fetching RADOLAN {product} for {day}...")
        grids = list(c.iter_radolan_grids(product, day, day, hour=hour))
        if not grids:
            raise QgsProcessingException("No RADOLAN grid found for that date/hour.")
        g = grids[0]
        feedback.pushInfo(f"Source: {g['url']}")
        feedback.pushInfo(f"Interval (UTC): {g['start']:%Y-%m-%d %H:%M} to {g['end']:%Y-%m-%d %H:%M}")

        dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        rl.write_radolan_geotiff(dest, g["data"])

        try:
            details = context.layerToLoadOnCompletionDetails(dest)
            processor = _StyleRadolanPostProcessor(rl.radolan_colour_max(g["data"]))
            details.setPostProcessor(processor)
            self._post_processor = processor
        except Exception:
            pass

        return {self.OUTPUT: dest}
